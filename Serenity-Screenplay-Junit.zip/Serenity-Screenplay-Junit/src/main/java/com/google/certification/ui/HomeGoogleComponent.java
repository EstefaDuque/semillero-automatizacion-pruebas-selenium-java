
package com.google.certification.ui;
 
import net.serenitybdd.core.pages.PageObject;
 
public class HomeGoogleComponent extends PageObject {
	public static final String WHAT_NEEDS_TO_BE_DONE = "q";
}