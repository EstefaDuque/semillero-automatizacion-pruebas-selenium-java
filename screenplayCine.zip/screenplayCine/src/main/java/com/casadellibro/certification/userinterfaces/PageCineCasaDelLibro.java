package com.casadellibro.certification.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://www.casadellibro.com/")
public class PageCineCasaDelLibro extends PageObject{

}
