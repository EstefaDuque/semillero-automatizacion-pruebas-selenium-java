package com.latam.certification.models;

public class AdultPassenger {
	
	private String adultName;
	private String adultLastname;
	private String adultIdType;
	private String adultIdNumber;
	private String adultOrigineCountry;
	public String getAdultName() {
		return adultName;
	}
	public void setAdultName(String adultName) {
		this.adultName = adultName;
	}
	public String getAdultLastname() {
		return adultLastname;
	}
	public void setAdultLastname(String adultLastname) {
		this.adultLastname = adultLastname;
	}
	public String getAdultIdType() {
		return adultIdType;
	}
	public void setAdultIdType(String adultIdType) {
		this.adultIdType = adultIdType;
	}
	public String getAdultIdNumber() {
		return adultIdNumber;
	}
	public void setAdultIdNumber(String adultIdNumber) {
		this.adultIdNumber = adultIdNumber;
	}
	public String getAdultOrigineCountry() {
		return adultOrigineCountry;
	}
	public void setAdultOrigineCountry(String adultOrigineCountry) {
		this.adultOrigineCountry = adultOrigineCountry;
	}
	
	
}
