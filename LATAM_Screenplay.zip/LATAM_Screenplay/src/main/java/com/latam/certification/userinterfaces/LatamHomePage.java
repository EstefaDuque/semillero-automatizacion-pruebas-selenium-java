package com.latam.certification.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

//Mapea la url de la p�gina
@DefaultUrl("https://www.latam.com/es_co/")
public class LatamHomePage extends PageObject {}

