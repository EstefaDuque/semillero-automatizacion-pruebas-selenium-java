//Importaci�n de librerias de selenium

import org.openqa.selenium.chrome.ChromeDriver; // Libreria para abrir el navegador.
import org.openqa.selenium.WebDriver; // Libreria para el driver.
import org.openqa.selenium.By; //forma de busqueda.
//--------------------------------------------------

public class MiPrimerClase {

	public static void main(String[] args) {
		
		//Le estamos indicando a selenium la ubicaci�n del driver para chrome.
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe"); 
		
		//Para abrir el navegador.
		WebDriver Automat = new ChromeDriver();
		
		//Para abrir una url en especifico.
		Automat.get("https://www.casadellibro.com/opiniones-multimedia/deadpool-2---blu-ray--/0/6545187"); 
		
		//Encuentra un elemento por medio del nombre, en nuestro caso es un campo de texto y escribe en el la palabra gmail.
		//Automat.findElement(By.name("q")).sendKeys("gmail"); 
		//Buscarlo por medio del xpath
		Automat.findElement(By.xpath("//a[@class='btn05compra purchase-button']")).click(); 		

	}

}
