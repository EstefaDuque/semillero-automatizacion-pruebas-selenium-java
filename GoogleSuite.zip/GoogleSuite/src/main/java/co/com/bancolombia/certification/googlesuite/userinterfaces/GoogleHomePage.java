package co.com.bancolombia.certification.googlesuite.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

//Mapea la url de la p�gina
@DefaultUrl("https://www.google.com/")
public class GoogleHomePage extends PageObject {}
